Thanks for using my resourcepack!

Terms of use

 I forbid you to use my resourcepacks/mods for commercial purposes,
 to use them in third-party projects, paid modpacks,
 on public servers with paid pass or donation,
 as well as to distribute them on other sites It is also forbidden
 to use textures from my projects for training neural networks

If you are interested in my services as a texturer or modeller,
you can go to my discord: (I also look forward to hearing from you for 
communication or ideas for future projects.)

https://discord.gg/mThvczzpuV

Donation and exclusive content: 

https://boosty.to/lanostry

<3

